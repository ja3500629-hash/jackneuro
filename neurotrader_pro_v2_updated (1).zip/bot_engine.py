"""
NEUROTRADER PRO — Motor de Señales Premium (OTC)
Estrategias:
  1. Soporte/Resistencia Fuerte + Tendencia EMA10/20 + Confirmación CMF/MFM
  2. Línea de Tendencia (3er toque) + Tendencia EMA10/20 + Confirmación CMF/MFM
Mercado: OTC (binarias 1 minuto) | Detección automática de activos
"""
import time
import logging
import json as _json
import os as _os
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import pytz
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

ecuador = pytz.timezone("America/Guayaquil")

# ─────────────────────────────────────────────
# CONSTANTES GLOBALES
# ─────────────────────────────────────────────
VENCIMIENTO_MINUTOS        = 1
MAX_CONCURRENT_TRADES      = 1       # solo 1 operación por ciclo (la mejor)
VENTANA_ENTRADA_INICIO_SEG = 58      # ventana de entrada: segundos 58 → 02
VENTANA_ENTRADA_FIN_SEG    = 2
PAUSA_ESCANEO_SEG          = 5       # escanear cada 5s (10 activos por ronda)
PAUSA_EJECUCION_SEG        = 0.5     # revisar ventana de entrada cada 500ms
RIESGO_AUTO_PCT            = 0.03    # 3% del balance para modo automático
MAX_ACTIVOS_ESCANEO        = 10      # 10 activos por ronda
SEÑAL_EXPIRY_SEG           = 55      # Señales válidas máximo 55 segundos

# ── Filtros y umbrales de las nuevas estrategias ─────────────────────────────
MIN_SCORE_PREMIUM          = 75      # Score mínimo total (sobre 100)
MIN_TOQUES_SR              = 3       # S/R fuerte: mínimo 3 toques
MIN_TOQUES_TREND_LINE      = 3       # Línea de tendencia: 3er toque obligatorio
SR_ATR_TOLERANCIA          = 2.5     # Tolerancia zona S/R en múltiplos de ATR

CMF_UMBRAL                 = 0.10    # Chaikin Money Flow > 0.10 = compradores fuertes
MFM_UMBRAL                 = 0.65    # Money Flow Multiplier > 0.65 = vela direccional fuerte
ATR_CALMA_PCT              = 0.0035  # ATR/precio < 0.35% = mercado tranquilo

EMA_CORTA                  = 10      # EMA rápida (tendencia inmediata)
EMA_MEDIA                  = 20      # EMA media (confirmación de tendencia)
EMA_LARGA                  = 50      # EMA lenta (filtro general)
EMA_TOLERANCIA_PCT         = 0.0008  # 0.08% tolerancia para "iguales"

# ─────────────────────────────────────────────
# SISTEMA DE LICENCIAS
# ─────────────────────────────────────────────
LICENCIAS_FILE = "licencias.json"


def _cargar_licencias() -> dict:
    if _os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, 'r', encoding='utf-8') as f:
                return _json.load(f)
        except Exception:
            pass
    return {}


def validar_licencia(codigo: str, email: str = None) -> tuple:
    codigo = codigo.strip().upper() if codigo else ""
    if not codigo:
        return False, "Código de licencia requerido"
    licencias = _cargar_licencias()
    if not licencias:
        return False, "No hay licencias registradas. Contacte al administrador."
    if codigo not in licencias:
        return False, f"Código '{codigo}' no válido"
    lic = licencias[codigo]
    if not lic.get('active', True):
        return False, "Licencia desactivada. Contacte al administrador."
    expires = lic.get('expires')
    if expires:
        try:
            exp_date = datetime.fromisoformat(expires)
            if 'T' not in expires and ':' not in expires:
                exp_date = exp_date.replace(hour=23, minute=59, second=59)
            if datetime.now() > exp_date:
                return False, f"Licencia expirada el {expires[:10]}"
        except Exception:
            pass
    lic_email = lic.get('email', '').strip().lower()
    if lic_email and email:
        if email.strip().lower() != lic_email:
            return False, "Este código no corresponde al correo ingresado"
    plan = lic.get('plan', '')
    plan_txt = {
        'semanal': 'Plan Semanal',
        'mensual': 'Plan Mensual',
        'vitalicio': 'Plan Vitalicio'
    }.get(plan, 'acceso completo')
    return True, f"Licencia válida — {plan_txt}"


def crear_licencia(codigo: str, descripcion: str = '', expires: str = None) -> bool:
    licencias = _cargar_licencias()
    licencias[codigo.strip().upper()] = {
        'active':      True,
        'descripcion': descripcion,
        'expires':     expires,
        'creado':      datetime.now().isoformat()[:19],
    }
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            _json.dump(licencias, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────
# HELPERS DE SÍMBOLO
# ─────────────────────────────────────────────

def _limpiar_simbolo(asset: str) -> str:
    """Normaliza el símbolo al nombre base sin sufijos (-OTC, -OP, etc.)."""
    a = str(asset or '').upper().strip()
    for suf in ('-OTC', ' OTC', '_OTC', '-OP', '_OP', '-op', '_op'):
        a = a.replace(suf.upper(), '')
    a = a.replace('/', '').replace('-', '').replace('_', '').replace(' ', '')
    return a[:8]


def _simbolo_candle(asset: str) -> str:
    """
    Para OTC, IQ Option requiere el sufijo -OTC en get_candles también.
    Si el activo viene con -OTC lo conservamos; si no, devolvemos limpio.
    """
    a = str(asset or '').upper().strip()
    if 'OTC' in a:
        base = _limpiar_simbolo(a)
        return f"{base}-OTC"
    return _limpiar_simbolo(a)


# ─────────────────────────────────────────────
# ESTADO DEL BOT
# ─────────────────────────────────────────────

class BotState:
    def __init__(self):
        self.running = False
        self.logs = []
        self.trades = []
        self.active_trades: list = []
        self.saldo = 0.0
        self.saldo_inicial = 0.0
        self.api = None
        self.tipo_cuenta = "PRACTICE"
        self.modo_mercado = "OTC"    # Solo OTC (binarias 24/7)
        # Gestión de riesgo
        self.modo_riesgo = "automatico"   # "automatico" | "fijo"
        self.monto_fijo = 1.0
        self.monto = 1.0
        # Stats
        self.stats = {
            'total': 0,
            'ganadas': 0,
            'perdidas': 0,
            'devueltas': 0,
            'profit': 0.0,
        }
        self.activos_disponibles = []
        self.señal_actual = None
        self.señales_pendientes: list = []
        self._señales_ts: float = 0.0
        self._ventana_ejecutada: bool = False
        self.scan_progreso = 0
        self.scan_total = 0
        self._email = ""
        self._password = ""
        self._ultimo_refresh_activos = 0
        self.diagnostico = {
            'estado': 'Esperando conexión',
            'ultimo_lote': 'Sin escaneo todavía',
            'mejor_candidato': None,
            'ultimo_bloqueo': 'Ninguno',
            'ultima_ejecucion': 'Ninguna',
            'eventos': [],
            'ultimo_analisis': {},
        }

    def _calcular_monto(self) -> float:
        if self.modo_riesgo == "automatico":
            return max(round(self.saldo * RIESGO_AUTO_PCT, 2), 0.50)
        return max(round(float(self.monto_fijo), 2), 0.50)

    def add_log(self, msg, nivel="INFO"):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        self.logs.append({"time": ts, "msg": msg, "nivel": nivel})
        if len(self.logs) > 500:
            self.logs = self.logs[-500:]
        try:
            with open("neurotrader_runtime.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now(ecuador).isoformat()} [{nivel}] {msg}\n")
        except Exception:
            pass

    def add_debug(self, msg, tipo="INFO", **extra):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        evento = {'time': ts, 'tipo': tipo, 'msg': msg}
        evento.update(extra)
        self.diagnostico.setdefault('eventos', []).append(evento)
        self.diagnostico['eventos'] = self.diagnostico['eventos'][-150:]
        if tipo in ('WARN', 'ERROR', 'BLOCK'):
            self.diagnostico['ultimo_bloqueo'] = msg
        elif tipo == 'TRADE':
            self.diagnostico['ultima_ejecucion'] = msg
        else:
            self.diagnostico['estado'] = msg
        try:
            datos = " ".join(f"{k}={v}" for k, v in extra.items()
                             if k not in ("email", "password"))
            with open("neurotrader_runtime.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now(ecuador).isoformat()} [DEBUG:{tipo}] {msg} {datos}\n")
        except Exception:
            pass

    def add_trade(self, trade):
        self.trades.append(trade)
        self.stats['total'] += 1
        gano = trade['estado'] == 'GANADA'
        if gano:
            self.stats['ganadas'] += 1
            self.stats['profit'] += trade.get('ganancia', 0)
        elif trade['estado'] == 'PERDIDA':
            self.stats['perdidas'] += 1
            self.stats['profit'] -= trade['monto']
        else:
            self.stats['devueltas'] += 1
        if len(self.trades) > 300:
            self.trades = self.trades[-300:]

    @property
    def win_rate(self):
        cerradas = self.stats['ganadas'] + self.stats['perdidas']
        return (self.stats['ganadas'] / cerradas * 100) if cerradas > 0 else 0.0

    @property
    def current_trade(self):
        return self.active_trades[0] if self.active_trades else None


# ─────────────────────────────────────────────
# OBTENCIÓN DE ACTIVOS
# ─────────────────────────────────────────────

def obtener_activos_disponibles(api, modo_mercado="OTC", limite: int = MAX_ACTIVOS_ESCANEO):
    """
    Retorna TODOS los activos OTC abiertos en IQ Option (binarias).
    Sin lista blanca: detección automática de lo que esté disponible.
    Limita a `limite` activos para mantener el ciclo de escaneo en 5 segundos.

    Prioriza pares mayores (EUR, USD, GBP, JPY) sobre exóticos.
    """
    PRIORIDAD = [
        'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCHF', 'USDCAD',
        'NZDUSD', 'EURJPY', 'GBPJPY', 'EURGBP', 'AUDJPY', 'EURAUD',
        'GBPCAD', 'EURCAD', 'EURCHF', 'AUDCAD', 'AUDCHF', 'AUDNZD',
        'CADCHF', 'CADJPY', 'CHFJPY', 'GBPCHF', 'GBPNZD', 'NZDJPY',
    ]
    try:
        open_time = api.get_all_open_time()
        otc_disponibles = set()
        if isinstance(open_time, dict):
            for seccion in ('binary', 'turbo'):
                for asset_key, data in open_time.get(seccion, {}).items():
                    if not data.get('open', False):
                        continue
                    if 'OTC' not in str(asset_key).upper():
                        continue
                    base = _limpiar_simbolo(asset_key)
                    if not base or len(base) < 5:
                        continue
                    otc_disponibles.add(base)

        if not otc_disponibles:
            return []

        # Ordenar: primero los de la lista de prioridad, luego el resto
        ordenados = []
        for p in PRIORIDAD:
            if p in otc_disponibles:
                ordenados.append(p + '-OTC')
                otc_disponibles.discard(p)
        # Añadir los que sobren alfabéticamente
        for r in sorted(otc_disponibles):
            ordenados.append(r + '-OTC')

        return ordenados[:limite]
    except Exception as e:
        logger.error(f"Error activos: {e}")
        return []


# ─────────────────────────────────────────────
# OBTENCIÓN DE VELAS CON CACHÉ
# ─────────────────────────────────────────────

_velas_cache: dict = {}
_VELAS_TTL = 4


def obtener_velas(api, asset: str, n: int = 100, forzar_fresco: bool = False):
    """
    Obtiene velas M1 con caché corto.
    Usa el símbolo base limpio para get_candles().
    """
    simbolo = _simbolo_candle(asset)
    ahora_ts = time.time()
    if not forzar_fresco:
        cached = _velas_cache.get(simbolo)
        if cached and (ahora_ts - cached[0]) < _VELAS_TTL:
            return cached[1]
    try:
        candles = api.get_candles(simbolo, 60, n, ahora_ts)
        if not candles or len(candles) < 30:
            return None
        df = pd.DataFrame(candles)
        for col in ['open', 'max', 'min', 'close', 'volume']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(subset=['open', 'close', 'max', 'min'], inplace=True)
        if len(df) < 30:
            return None
        df.rename(columns={'max': 'high', 'min': 'low'}, inplace=True)
        df = df.reset_index(drop=True)
        _velas_cache[simbolo] = (ahora_ts, df)
        return df
    except Exception as e:
        logger.debug(f"get_candles({simbolo}): {e}")
        return None


# ─────────────────────────────────────────────
# CÁLCULO DE INDICADORES TÉCNICOS
# ─────────────────────────────────────────────

def calcular_indicadores(df: pd.DataFrame) -> pd.DataFrame:
    """
    Indicadores profesionales para análisis cuantitativo:
    - EMA 10 / 20 / 50: tendencia corta, media y larga
    - ATR 14: volatilidad (filtro de mercado tranquilo)
    - Stochastic %K %D (14,3): momentum
    - MFM (Money Flow Multiplier): dirección de la vela actual (-1 a +1)
    - CMF 20 (Chaikin Money Flow): presión compradora vs vendedora (-1 a +1)
    - RSI 14: confirmación adicional de momentum
    - Cuerpo/rango: fuerza de la vela actual
    """
    df = df.copy()
    close  = df['close'].astype(float)
    high   = df['high'].astype(float)
    low    = df['low'].astype(float)
    op     = df['open'].astype(float)
    # En OTC el volumen real no existe — usamos rango como proxy de actividad
    volume = df.get('volume', pd.Series(np.nan, index=df.index)).astype(float)
    if volume.isna().all() or (volume == 0).all():
        volume = (high - low).abs().replace(0, 1e-9)

    # ── EMAs ──────────────────────────────────────────────────────────────
    df['ema10'] = close.ewm(span=EMA_CORTA, adjust=False).mean()
    df['ema20'] = close.ewm(span=EMA_MEDIA, adjust=False).mean()
    df['ema50'] = close.ewm(span=EMA_LARGA, adjust=False).mean()

    # ── ATR 14 (volatilidad) ──────────────────────────────────────────────
    tr = pd.concat([
        high - low,
        (high - close.shift(1)).abs(),
        (low  - close.shift(1)).abs()
    ], axis=1).max(axis=1)
    df['atr'] = tr.rolling(14).mean()

    # ── Stochastic %K / %D (14,3) ─────────────────────────────────────────
    low14  = low.rolling(14).min()
    high14 = high.rolling(14).max()
    rng14 = (high14 - low14).replace(0, np.nan)
    df['stoch_k'] = ((close - low14) / rng14 * 100).fillna(50)
    df['stoch_d'] = df['stoch_k'].rolling(3).mean()

    # ── MFM per-candle (Money Flow Multiplier) ────────────────────────────
    # Mide dónde cerró la vela dentro de su rango: +1 = cerró arriba (alcista)
    #                                              -1 = cerró abajo (bajista)
    hl = (high - low).replace(0, np.nan)
    df['mfm'] = ((close - low) - (high - close)) / hl
    df['mfm'] = df['mfm'].fillna(0)

    # ── CMF 20 (Chaikin Money Flow) ───────────────────────────────────────
    # Suma ponderada por volumen del MFM en 20 velas. -1 a +1
    mfv = df['mfm'] * volume
    df['cmf'] = (mfv.rolling(20).sum() / volume.rolling(20).sum()).fillna(0)

    # ── RSI 14 ────────────────────────────────────────────────────────────
    delta = close.diff()
    ganancia = delta.where(delta > 0, 0.0).rolling(14).mean()
    perdida  = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
    rs       = ganancia / perdida.replace(0, np.nan)
    df['rsi'] = (100 - (100 / (1 + rs))).fillna(50)

    # ── MFI 14 (Money Flow Index — RSI con volumen) ───────────────────────
    tp = (high + low + close) / 3
    raw_mf = tp * volume
    pos_mf = raw_mf.where(tp > tp.shift(1), 0.0).fillna(0)
    neg_mf = raw_mf.where(tp < tp.shift(1), 0.0).fillna(0)
    pos14  = pos_mf.rolling(14).sum()
    neg14  = neg_mf.rolling(14).sum()
    mfr    = pos14 / neg14.replace(0, np.nan)
    df['mfi'] = (100 - (100 / (1 + mfr))).fillna(50)

    # ── Cuerpo/rango de la vela actual (fuerza) ───────────────────────────
    cuerpo = (close - op).abs()
    rango  = (high - low).replace(0, np.nan)
    df['cuerpo_pct'] = (cuerpo / rango).fillna(0)
    df['vela_alcista'] = close > op

    return df


# ─────────────────────────────────────────────
# DETECCIÓN DE ZONAS S/R
# ─────────────────────────────────────────────

def _agrupar_niveles(niveles, tolerancia):
    if not niveles:
        return []
    niveles = sorted(float(n) for n in niveles)
    grupos = []
    actual = [niveles[0]]
    for n in niveles[1:]:
        if abs(n - actual[-1]) <= tolerancia:
            actual.append(n)
        else:
            grupos.append(sum(actual) / len(actual))
            actual = [n]
    grupos.append(sum(actual) / len(actual))
    return grupos


def detectar_zona_sr(df: pd.DataFrame, direccion: str):
    """
    Detecta zona S/R con ≥ MIN_TOQUES_SR toques.
    Retorna (en_zona, nivel, num_toques)
    """
    if len(df) < 30:
        return False, None, 0

    u   = df.iloc[-1]
    atr = max(float(u.get('atr', float(u['high']) - float(u['low']))), 1e-9)
    tol_zona   = atr * SR_ATR_TOLERANCIA
    tol_grupo  = max(atr * 0.5, abs(float(u['close'])) * 0.0001, 1e-9)

    seg = df.iloc[-80:-1] if len(df) >= 80 else df.iloc[:-1]

    if direccion == 'CALL':
        vals      = seg['low'].astype(float).tolist()
        swings    = [vals[i] for i in range(1, len(vals) - 1)
                     if vals[i] <= vals[i - 1] and vals[i] <= vals[i + 1]]
        precio_ref = min(float(u['low']), float(u['close']))
    else:
        vals      = seg['high'].astype(float).tolist()
        swings    = [vals[i] for i in range(1, len(vals) - 1)
                     if vals[i] >= vals[i - 1] and vals[i] >= vals[i + 1]]
        precio_ref = max(float(u['high']), float(u['close']))

    niveles = _agrupar_niveles(swings, tol_grupo * 1.8)

    mejor_nivel  = None
    mejor_toques = 0
    for nivel in niveles:
        toques = sum(1 for v in vals if abs(v - nivel) <= tol_grupo * 2)
        if toques >= MIN_TOQUES_SR and abs(precio_ref - nivel) <= tol_zona:
            if toques > mejor_toques:
                mejor_toques = toques
                mejor_nivel  = nivel

    if mejor_nivel is not None:
        return True, mejor_nivel, mejor_toques
    return False, None, 0


# ─────────────────────────────────────────────
# DETECCIÓN DE LÍNEA DE TENDENCIA (regresión lineal de swings)
# ─────────────────────────────────────────────

def detectar_linea_tendencia(df: pd.DataFrame, direccion: str):
    """
    Detecta línea de tendencia diagonal por regresión lineal sobre los swings.
    - CALL: línea ascendente uniendo swing-lows (soporte dinámico)
    - PUT:  línea descendente uniendo swing-highs (resistencia dinámica)

    Retorna (en_toque, num_toques, pendiente, valor_actual_linea).
    Solo válido si hay ≥3 toques confirmados a la línea.
    """
    if len(df) < 30:
        return False, 0, 0.0, None

    seg = df.iloc[-60:].reset_index(drop=True) if len(df) >= 60 else df.reset_index(drop=True)
    n = len(seg)
    u = df.iloc[-1]
    atr = max(float(u.get('atr', float(u['high']) - float(u['low']))), 1e-9)
    tol = atr * 0.6   # tolerancia para considerar "toque"

    # Swings (mínimos locales para CALL, máximos para PUT)
    if direccion == 'CALL':
        idxs   = [i for i in range(2, n-2)
                  if seg['low'].iloc[i] <= seg['low'].iloc[i-1]
                  and seg['low'].iloc[i] <= seg['low'].iloc[i-2]
                  and seg['low'].iloc[i] <= seg['low'].iloc[i+1]
                  and seg['low'].iloc[i] <= seg['low'].iloc[i+2]]
        valores = [float(seg['low'].iloc[i]) for i in idxs]
        precio_actual = min(float(u['low']), float(u['close']))
    else:
        idxs   = [i for i in range(2, n-2)
                  if seg['high'].iloc[i] >= seg['high'].iloc[i-1]
                  and seg['high'].iloc[i] >= seg['high'].iloc[i-2]
                  and seg['high'].iloc[i] >= seg['high'].iloc[i+1]
                  and seg['high'].iloc[i] >= seg['high'].iloc[i+2]]
        valores = [float(seg['high'].iloc[i]) for i in idxs]
        precio_actual = max(float(u['high']), float(u['close']))

    if len(idxs) < 3:
        return False, 0, 0.0, None

    # Regresión lineal sobre los swings: y = mx + b
    xs = np.array(idxs, dtype=float)
    ys = np.array(valores, dtype=float)
    if xs.std() < 1e-9:
        return False, 0, 0.0, None
    pendiente, intercepto = np.polyfit(xs, ys, 1)

    # Validar dirección: ascendente para CALL, descendente para PUT
    if direccion == 'CALL' and pendiente <= 0:
        return False, 0, 0.0, None
    if direccion == 'PUT'  and pendiente >= 0:
        return False, 0, 0.0, None

    # Contar toques (puntos cerca de la línea)
    toques = 0
    for x, y in zip(xs, ys):
        y_linea = pendiente * x + intercepto
        if abs(y - y_linea) <= tol:
            toques += 1

    if toques < MIN_TOQUES_TREND_LINE:
        return False, toques, pendiente, None

    # Valor de la línea en el momento actual (último índice)
    valor_actual = pendiente * (n - 1) + intercepto

    # ¿El precio actual está tocando la línea? (3er toque o más)
    distancia = abs(precio_actual - valor_actual)
    if distancia > tol * 1.3:
        return False, toques, pendiente, valor_actual

    return True, toques, pendiente, valor_actual


# ─────────────────────────────────────────────
# EVALUACIÓN DE SEÑAL PREMIUM (2 estrategias OTC)
# ─────────────────────────────────────────────

def evaluar_senal_premium(df: pd.DataFrame, asset: str):
    """
    Analiza el activo con DOS estrategias y devuelve la mejor señal.

    ───── ESTRATEGIA 1: SOPORTE/RESISTENCIA FUERTE ─────
    Filtros DUROS:
      • Mercado tranquilo (ATR/precio < umbral)
      • EMA10 vs EMA20 alineadas con la dirección
      • Zona S/R con ≥3 toques confirmados
    Confirmación (suma puntos):
      • CMF y MFM en la dirección correcta
      • EMA50 alineada
      • Cuerpo de vela actual fuerte y direccional

    ───── ESTRATEGIA 2: LÍNEA DE TENDENCIA (3er toque) ─────
    Filtros DUROS:
      • Mercado tranquilo
      • Línea de tendencia diagonal con ≥3 toques (regresión lineal)
      • EMA10 vs EMA20 alineadas
      • S/R cercano apoyando (puede ser solo 2 toques)
    Confirmación: misma lógica de presión (CMF + MFM + cuerpo)

    Retorna la dirección (CALL/PUT) con mayor score combinado.
    """
    if len(df) < 60:
        return None, "datos insuficientes (<60 velas)"

    df = calcular_indicadores(df)
    u  = df.iloc[-1]

    close = float(u['close'])
    ema10 = float(u['ema10']) if not pd.isna(u['ema10']) else close
    ema20 = float(u['ema20']) if not pd.isna(u['ema20']) else close
    ema50 = float(u['ema50']) if not pd.isna(u['ema50']) else close
    atr   = float(u['atr'])   if not pd.isna(u.get('atr',   np.nan)) else 0.0
    mfm   = float(u['mfm'])
    cmf   = float(u['cmf'])   if not pd.isna(u.get('cmf',   np.nan)) else 0.0
    rsi   = float(u['rsi'])   if not pd.isna(u.get('rsi',   np.nan)) else 50.0
    cuerpo_pct  = float(u['cuerpo_pct'])
    vela_alc    = bool(u['vela_alcista'])

    # Filtro mercado tranquilo (común a las 2 estrategias)
    atr_pct = atr / close if close > 0 else 1.0
    if atr_pct > ATR_CALMA_PCT:
        return None, f"mercado volátil (ATR={atr_pct*100:.2f}% > {ATR_CALMA_PCT*100:.2f}%)"

    resultados = []
    razones = {}

    for direccion in ('CALL', 'PUT'):
        bandas_ema = ema20 * EMA_TOLERANCIA_PCT

        # ── Filtro EMA10/EMA20 alineadas con la dirección ─────────────────
        if direccion == 'CALL':
            if not (ema10 > ema20 - bandas_ema and close >= ema20 - bandas_ema):
                razones[direccion] = (
                    f"EMA10({ema10:.5f}) ≤ EMA20({ema20:.5f}) — sin tendencia alcista"
                )
                continue
        else:
            if not (ema10 < ema20 + bandas_ema and close <= ema20 + bandas_ema):
                razones[direccion] = (
                    f"EMA10({ema10:.5f}) ≥ EMA20({ema20:.5f}) — sin tendencia bajista"
                )
                continue

        # ── ESTRATEGIA 1: S/R FUERTE ──────────────────────────────────────
        en_sr, nivel_sr, toques_sr = detectar_zona_sr(df, direccion)

        # ── ESTRATEGIA 2: LÍNEA DE TENDENCIA ──────────────────────────────
        en_lt, toques_lt, pend_lt, val_lt = detectar_linea_tendencia(df, direccion)

        # Necesitamos al menos UNA estrategia activa
        if not en_sr and not en_lt:
            razones[direccion] = "Sin S/R fuerte (≥3 toques) ni línea de tendencia (3er toque)"
            continue

        # ══════════════════════════════════════════════════════════════════
        # SCORING — base por estructura + presión (CMF/MFM) + confirmaciones
        # ══════════════════════════════════════════════════════════════════
        detalle = {}
        score = 0
        estrategia_usada = []

        # Puntos por estructura: S/R fuerte = 30-45, línea tendencia = 20-30
        pts_estructura = 0
        if en_sr:
            pts_estructura += min(30 + (toques_sr - 3) * 3, 45)
            estrategia_usada.append(f"S/R-{toques_sr}t")
            detalle['nivel_sr']  = nivel_sr
            detalle['toques_sr'] = toques_sr
        if en_lt:
            pts_estructura += min(20 + (toques_lt - 3) * 3, 30)
            estrategia_usada.append(f"LT-{toques_lt}t")
            detalle['linea_tend']    = round(val_lt, 5) if val_lt else None
            detalle['toques_lt']     = toques_lt
            detalle['pendiente_lt']  = round(pend_lt, 8) if pend_lt else None
        score += pts_estructura

        # ── Confirmación CMF (Chaikin Money Flow) ─────────────────────────
        if direccion == 'CALL':
            if cmf >= CMF_UMBRAL:
                pts_cmf = 18              # presión compradora confirmada
            elif cmf >= 0:
                pts_cmf = 8
            else:
                pts_cmf = 0               # presión vendedora — mala señal
        else:
            if cmf <= -CMF_UMBRAL:
                pts_cmf = 18
            elif cmf <= 0:
                pts_cmf = 8
            else:
                pts_cmf = 0
        score += pts_cmf
        detalle['cmf'] = round(cmf, 3)

        # ── Confirmación MFM (Money Flow Multiplier de la última vela) ────
        if direccion == 'CALL':
            if mfm >= MFM_UMBRAL:
                pts_mfm = 12
            elif mfm >= 0.30:
                pts_mfm = 7
            elif mfm >= 0:
                pts_mfm = 3
            else:
                pts_mfm = 0
        else:
            if mfm <= -MFM_UMBRAL:
                pts_mfm = 12
            elif mfm <= -0.30:
                pts_mfm = 7
            elif mfm <= 0:
                pts_mfm = 3
            else:
                pts_mfm = 0
        score += pts_mfm
        detalle['mfm'] = round(mfm, 3)

        # ── EMA50 alineada (bonus) ────────────────────────────────────────
        if direccion == 'CALL' and close >= ema50:
            score += 7
            detalle['ema50_ok'] = True
        elif direccion == 'PUT' and close <= ema50:
            score += 7
            detalle['ema50_ok'] = True
        else:
            detalle['ema50_ok'] = False

        # ── Cuerpo de vela fuerte y en dirección ──────────────────────────
        cuerpo_alineado = (
            (direccion == 'CALL' and vela_alc) or
            (direccion == 'PUT' and not vela_alc)
        )
        if cuerpo_alineado and cuerpo_pct >= 0.55:
            score += 5
            detalle['vela_fuerte'] = True
        elif cuerpo_alineado:
            score += 2

        # ── RSI no extremo en contra ──────────────────────────────────────
        if direccion == 'CALL' and rsi <= 70:
            score += 3
        elif direccion == 'PUT'  and rsi >= 30:
            score += 3
        detalle['rsi'] = round(rsi, 1)

        score = min(score, 100)
        prob  = round(score / 100, 3)

        detalle['estrategia']    = " + ".join(estrategia_usada) if estrategia_usada else "?"
        detalle['ema10']         = round(ema10, 5)
        detalle['ema20']         = round(ema20, 5)
        detalle['atr_pct']       = round(atr_pct * 100, 3)
        detalle['cuerpo_pct']    = round(cuerpo_pct, 2)

        resultados.append({
            'direccion':    direccion,
            'score':        score,
            'prob':         prob,
            'nivel_sr':     nivel_sr if en_sr else (val_lt if en_lt else None),
            'toques_sr':    toques_sr if en_sr else toques_lt,
            'estrategia':   detalle['estrategia'],
            'detalle':      detalle,
            'motivo_fallo': [],
        })

    if not resultados:
        motivo = " | ".join(razones.values()) if razones else "Sin señal válida"
        return None, motivo

    resultados.sort(key=lambda x: -x['score'])
    return resultados[0], "OK"


# ─────────────────────────────────────────────
# VENTANA DE ENTRADA
# ─────────────────────────────────────────────

def en_ventana_entrada() -> bool:
    """Ventana de entrada: segundos 57-03 de cada minuto."""
    seg = datetime.now(ecuador).second
    return seg >= VENTANA_ENTRADA_INICIO_SEG or seg <= VENTANA_ENTRADA_FIN_SEG


def _señales_vigentes(state: BotState) -> list:
    """Filtra señales que no han expirado (< SEÑAL_EXPIRY_SEG segundos)."""
    ahora_ts = time.time()
    if not state.señales_pendientes:
        return []
    edad = ahora_ts - state._señales_ts
    if edad > SEÑAL_EXPIRY_SEG:
        return []
    return state.señales_pendientes


# ─────────────────────────────────────────────
# MOTOR PRINCIPAL DEL BOT
# ─────────────────────────────────────────────

def bot_engine(state: BotState):
    """
    Motor principal con bucle dual:
    - Escaneo de señales: cada PAUSA_ESCANEO_SEG segundos
    - Chequeo de ventana de entrada: cada PAUSA_EJECUCION_SEG (0.5s)
    Solo ejecuta 1 operación por ciclo (la de mayor score).
    """
    state.modo_mercado = "OTC"
    state.add_log("🤖 Motor NeuroTrader Pro iniciado — Mercado OTC | 1 op por ciclo", "INFO")
    state.add_log(
        f"Estrategias: 1) S/R Fuerte ≥{MIN_TOQUES_SR} toques  "
        f"2) Línea Tendencia (3er toque)  |  Venc: {VENCIMIENTO_MINUTOS} min", "INFO"
    )
    state.add_log(
        f"Confirmadores: EMA{EMA_CORTA}/EMA{EMA_MEDIA}/EMA{EMA_LARGA} + "
        f"CMF≥{CMF_UMBRAL} + MFM≥{MFM_UMBRAL} + RSI + cuerpo de vela | "
        f"Score≥{MIN_SCORE_PREMIUM} | Mercado tranquilo (ATR<{ATR_CALMA_PCT*100:.2f}%)", "INFO"
    )

    ultimo_scan_ts = 0.0
    en_ventana_prev = False

    while state.running:
        try:
            ahora_ts = time.time()
            ahora    = datetime.now(ecuador)

            # ── Verificar operaciones activas ──────────────────────────────
            _verificar_operaciones_activas(state)

            # ── ESCANEO — cada PAUSA_ESCANEO_SEG segundos ─────────────────
            if ahora_ts - ultimo_scan_ts >= PAUSA_ESCANEO_SEG:
                ultimo_scan_ts = ahora_ts

                # Refresh de activos cada 5 minutos (auto-detección OTC)
                if ahora_ts - state._ultimo_refresh_activos > 300 or not state.activos_disponibles:
                    if state.api:
                        activos = obtener_activos_disponibles(state.api, "OTC")
                        if activos:
                            state.activos_disponibles = activos
                            state.add_log(
                                f"Activos OTC detectados: {len(activos)} | "
                                + ", ".join(activos[:6]) + ("..." if len(activos) > 6 else ""),
                                "INFO"
                            )
                        elif not state.activos_disponibles:
                            state.add_log("⚠️ No se detectaron activos OTC abiertos", "WARNING")
                        state._ultimo_refresh_activos = ahora_ts

                activos = state.activos_disponibles or []
                state.scan_total = len(activos)
                if not activos:
                    state.add_log("Sin activos OTC disponibles — esperando…", "WARNING")
                    time.sleep(PAUSA_ESCANEO_SEG)
                    continue

                candidatos  = []
                analisis_log = {}

                state.add_log(
                    f"─── Escaneando {len(activos)} activos [{ahora.strftime('%H:%M:%S')}] "
                    f"[{state.modo_mercado}] ───",
                    "INFO"
                )

                for idx, asset in enumerate(activos):
                    if not state.running:
                        break
                    state.scan_progreso = idx + 1

                    df = obtener_velas(state.api, asset)
                    if df is None or len(df) < 55:
                        motivo = f"Sin datos de velas (recibidas={len(df) if df is not None else 0})"
                        analisis_log[asset] = motivo
                        state.add_log(f"  {asset}: {motivo}", "INFO")
                        continue

                    señal, motivo = evaluar_senal_premium(df, asset)

                    if señal is None:
                        analisis_log[asset] = motivo
                        state.add_log(f"  {asset}: ✗ {motivo}", "INFO")
                        continue

                    if señal['score'] < MIN_SCORE_PREMIUM:
                        motivo = f"Score {señal['score']} < mínimo {MIN_SCORE_PREMIUM}"
                        analisis_log[asset] = motivo
                        state.add_log(
                            f"  {asset}: score bajo ({señal['score']}) — descartado",
                            "INFO"
                        )
                        continue

                    señal['asset'] = asset
                    candidatos.append(señal)
                    estrat = señal.get('estrategia', '?')
                    analisis_log[asset] = (
                        f"✅ {señal['direccion']} score={señal['score']} "
                        f"prob={señal['prob']:.0%} [{estrat}]"
                    )
                    d = señal['detalle']
                    state.add_log(
                        f"  {asset}: ✅ {señal['direccion']} score={señal['score']} "
                        f"[{estrat}] CMF={d.get('cmf','?')} MFM={d.get('mfm','?')} "
                        f"ATR%={d.get('atr_pct','?')}",
                        "SIGNAL"
                    )

                state.diagnostico['ultimo_analisis'] = analisis_log

                if candidatos:
                    state.señales_pendientes = candidatos
                    state._señales_ts = time.time()
                    state._ventana_ejecutada = False

                    best = max(candidatos, key=lambda x: x['score'])
                    state.diagnostico['mejor_candidato'] = {
                        'asset':     best['asset'],
                        'direccion': best['direccion'],
                        'score':     best['score'],
                        'prob':      best['prob'],
                    }
                    state.señal_actual = best
                    state.add_log(
                        f"  → {len(candidatos)} señal(es) — Mejor: {best['asset']} "
                        f"{best['direccion']} score={best['score']} prob={best['prob']:.0%}",
                        "SIGNAL"
                    )
                else:
                    vigentes = _señales_vigentes(state)
                    if not vigentes:
                        state.señales_pendientes = []
                        state.señal_actual = None
                    state.add_log(
                        f"  → Sin señales nuevas ({len(activos)} activos). "
                        + (f"{len(vigentes)} señal(es) prev. vigentes." if vigentes else ""),
                        "INFO"
                    )

                state.diagnostico['ultimo_lote'] = (
                    f"{len(candidatos)} señal(es) nueva(s) en {len(activos)} activos"
                )

            # ── EJECUCIÓN — revisar ventana cada 0.5 s ────────────────────
            en_ventana_ahora = en_ventana_entrada()

            if en_ventana_ahora:
                vigentes = _señales_vigentes(state)
                if vigentes and not state._ventana_ejecutada:
                    ops_libres = MAX_CONCURRENT_TRADES - len(state.active_trades)
                    if ops_libres > 0:
                        # Solo la mejor señal
                        mejor_señal = max(vigentes, key=lambda x: x['score'])
                        activos_activos = {t['asset'] for t in state.active_trades}
                        if mejor_señal['asset'] not in activos_activos:
                            if en_ventana_entrada():
                                ok = _ejecutar_operacion(state, mejor_señal)
                                if not ok:
                                    # Intentar con la siguiente mejor si la primera falla
                                    candidatos_ord = sorted(vigentes, key=lambda x: -x['score'])
                                    for s in candidatos_ord[1:]:
                                        if s['asset'] not in activos_activos and en_ventana_entrada():
                                            ok = _ejecutar_operacion(state, s)
                                            if ok:
                                                break
                                if not ok:
                                    state.add_log(
                                        "⚠ Todos los activos rechazados por API en esta ventana",
                                        "WARN"
                                    )
                            else:
                                state.add_log("Ventana cerrada — operación cancelada", "WARN")
                        else:
                            state.add_log(
                                f"  ⛔ {mejor_señal['asset']} ya tiene op activa — esperando",
                                "WARN"
                            )
                        state._ventana_ejecutada = True
                    else:
                        state.add_log(
                            f"Ventana abierta pero operación activa — esperando resultado",
                            "INFO"
                        )
            else:
                if en_ventana_prev:
                    state._ventana_ejecutada = False

            en_ventana_prev = en_ventana_ahora

        except Exception as e:
            state.add_log(f"Error en motor: {e}", "ERROR")
            logger.exception(f"Error en bot_engine: {e}")

        time.sleep(PAUSA_EJECUCION_SEG)

    state.add_log("Motor detenido.", "INFO")


# ── Tiempos para verificación de resultados ──────────────────────────────────
CHECK_WIN_GRACIA_SEG = 1    # esperar 1s tras el vencimiento real antes de consultar
CHECK_WIN_TIMEOUT_SEG = 15  # tras vencimiento + 15s, cerrar como DESCONOCIDA (forzado)
CHECK_WIN_INTERVAL  = 3    # re-intentar check_win cada 3 segundos


def _obtener_saldo_actual(api) -> float | None:
    """Obtiene el saldo actual del API con manejo de errores."""
    try:
        saldo = api.get_balance()
        if saldo:
            return float(saldo)
    except Exception:
        pass
    return None


def _consultar_resultado_op(api, id_op) -> float | None:
    """
    Consulta NO-BLOQUEANTE del resultado de una operación binaria.
    Solo usa get_optioninfo_v2 (lectura directa de socket) — NUNCA usa
    check_win_v3/v4 porque bloquean el hilo hasta que el broker responde.

    Retorna profit/loss en USD, o None si aún no hay resultado.
    """
    try:
        info = api.get_optioninfo_v2(id_op, 1)
    except Exception:
        info = None
    if not info or not isinstance(info, dict):
        return None

    # El campo principal es 'win' = 'win'/'equal'/'loose'/'lose' o vacío si no resuelta
    estado_op = str(info.get('win', '')).lower()
    if estado_op not in ('win', 'equal', 'loose', 'lose'):
        return None

    # Win amount = dinero recibido. Profit real = win_amount - amount apostado
    win_amount = float(info.get('win_amount', 0.0) or 0.0)
    amount     = float(info.get('amount',     0.0) or 0.0)
    if estado_op == 'win':
        return max(win_amount - amount, 0.01)
    if estado_op == 'equal':
        return 0.0
    return -amount if amount > 0 else -1.0


def _verificar_operaciones_activas(state: BotState):
    """
    Verifica resultado de operaciones activas y las cierra cuando venzan.

    Lógica basada en el VENCIMIENTO REAL guardado en `vence_iso` (no en
    edad de la operación). Para binarias 1-min en IQ Option el vencimiento
    es siempre el cierre del próximo minuto, así que algunas operaciones
    duran 2 segundos y otras hasta 119 segundos.

    FLUJO:
    - antes del vencimiento: no hacer nada
    - vencimiento + 1s: empezar a consultar resultado (get_optioninfo_v2)
    - vencimiento + 4s: probar también delta de balance (fallback)
    - vencimiento + 15s: cierre forzado como DESCONOCIDA (último intento balance)
    """
    ahora = datetime.now(ecuador)
    cerradas = []

    for trade in list(state.active_trades):
        if trade.get('estado') != 'PENDIENTE':
            continue

        # Vencimiento real en datetime
        try:
            vence_dt = datetime.fromisoformat(trade['vence_iso'])
        except Exception:
            # Compatibilidad: si no hay vence_iso, fallback a entrada+90s
            try:
                vence_dt = datetime.fromisoformat(trade['entrada_iso']) + timedelta(seconds=90)
            except Exception:
                vence_dt = ahora

        seg_post_vence = (ahora - vence_dt).total_seconds()

        # Aún no ha vencido — esperar
        if seg_post_vence < CHECK_WIN_GRACIA_SEG:
            continue

        id_op = trade.get('id_operacion')
        resultado = None

        # Intento 1: lectura directa por API (no bloqueante)
        if id_op and state.api:
            resultado = _consultar_resultado_op(state.api, id_op)

        # Intento 2: delta de balance (a partir de vence + 4s)
        if resultado is None and seg_post_vence >= 4 and state.api:
            saldo_actual = _obtener_saldo_actual(state.api)
            if saldo_actual is not None:
                state.saldo = saldo_actual
                saldo_pre = trade.get('saldo_pre_op')
                if saldo_pre is not None:
                    delta = saldo_actual - saldo_pre
                    if abs(delta) > 0.01:
                        resultado = delta
                        state.add_log(
                            f"  📊 Resultado por delta de balance: ${delta:+.2f}",
                            "INFO"
                        )

        # Cierre forzado tras CHECK_WIN_TIMEOUT_SEG
        if resultado is None and seg_post_vence >= CHECK_WIN_TIMEOUT_SEG:
            saldo_actual = _obtener_saldo_actual(state.api) if state.api else None
            if saldo_actual is not None:
                state.saldo = saldo_actual
                saldo_pre = trade.get('saldo_pre_op')
                if saldo_pre is not None:
                    delta = saldo_actual - saldo_pre
                    if abs(delta) > 0.01:
                        resultado = delta

            if resultado is None:
                trade['estado'] = 'DESCONOCIDA'
                state.add_log(
                    f"⏱ TIMEOUT {trade['asset']} {trade['direccion']} "
                    f"(+{int(seg_post_vence)}s post-vencimiento) — cerrado sin confirmación",
                    "WARN"
                )
                state.add_trade(trade)
                cerradas.append(trade)
                continue

        if resultado is None:
            continue  # seguir intentando hasta el timeout

        # ══════════════════════════════════════════════════════════════════
        # PROCESAR RESULTADO
        # ══════════════════════════════════════════════════════════════════
        try:
            resultado_f = float(resultado)
        except (TypeError, ValueError):
            resultado_f = -1.0

        if resultado_f > 0:
            trade['estado']   = 'GANADA'
            trade['ganancia'] = resultado_f
            state.add_log(
                f"✅ WIN {trade['asset']} {trade['direccion']} +${resultado_f:.2f}",
                "WIN"
            )
        elif resultado_f == 0:
            trade['estado'] = 'DEVUELTA'
            state.add_log(f"↩ EMPATE {trade['asset']} {trade['direccion']}", "INFO")
        else:
            trade['estado'] = 'PERDIDA'
            state.add_log(
                f"❌ LOSS {trade['asset']} {trade['direccion']} -${trade['monto']:.2f}",
                "LOSS"
            )

        saldo_post = _obtener_saldo_actual(state.api)
        if saldo_post is not None:
            state.saldo = saldo_post

        state.add_trade(trade)
        cerradas.append(trade)

    for t in cerradas:
        if t in state.active_trades:
            state.active_trades.remove(t)


def _ejecutar_operacion(state: BotState, señal: dict) -> bool:
    """
    Ejecuta una operación en IQ Option respetando el modo de mercado.
    - REAL: usa el símbolo base (EURUSD). NO hay fallback a OTC.
    - OTC:  usa el símbolo con sufijo -OTC (EURUSD-OTC).
    Retorna True si se colocó exitosamente, False si falló.
    """
    ahora  = datetime.now(ecuador)
    asset  = señal['asset']
    dir_op = señal['direccion'].lower()
    monto  = state._calcular_monto()

    if not state.api:
        state.add_log("Sin conexión API — operación cancelada", "WARN")
        return False

    try:
        # Guardar saldo ANTES de la operación (fallback de resultado por balance)
        saldo_pre_op = state.saldo
        try:
            saldo_fresco = state.api.get_balance()
            if saldo_fresco:
                saldo_pre_op = float(saldo_fresco)
                state.saldo  = saldo_pre_op
        except Exception:
            pass

        estado_op, id_op = state.api.buy(monto, asset, dir_op, VENCIMIENTO_MINUTOS)

        if not estado_op:
            state.add_log(
                f"❌ {asset} rechazado por API — mercado {state.modo_mercado} "
                f"no disponible ahora. Cambia a OTC si el REAL está cerrado.",
                "WARN"
            )
            return False

        # Calcular vencimiento REAL: en binarias IQ vence al cierre del próximo
        # minuto. Si quedan <30s en el minuto actual, salta al siguiente cierre.
        proximo_cierre = ahora.replace(second=0, microsecond=0) + timedelta(minutes=1)
        seg_hasta_cierre = (proximo_cierre - ahora).total_seconds()
        if seg_hasta_cierre < 30:
            vence_dt = proximo_cierre + timedelta(minutes=1)
        else:
            vence_dt = proximo_cierre

        trade = {
            'asset':             asset,
            'direccion':         señal['direccion'],
            'monto':             monto,
            'score':             señal['score'],
            'prob':              señal['prob'],
            'estado':            'PENDIENTE',
            'ganancia':          0.0,
            'entrada':           ahora.strftime('%H:%M:%S'),
            'entrada_iso':       ahora.isoformat(),
            'vencimiento':       vence_dt.strftime('%H:%M:%S'),
            'vence_iso':         vence_dt.isoformat(),
            'id_operacion':      id_op,
            'nombre_estrategia': 'S/R Premium',
            'nivel_sr':          señal.get('nivel_sr'),
            'toques_sr':         señal.get('toques_sr', 0),
            'mercado':           state.modo_mercado,
            'saldo_pre_op':      saldo_pre_op,   # usado en fallback por balance
        }
        state.active_trades.append(trade)
        state.add_log(
            f"🚀 {señal['direccion']} {asset} ${monto:.2f} | "
            f"score={señal['score']} prob={señal['prob']:.0%} | "
            f"SR={señal.get('nivel_sr', 'N/A')} toques={señal.get('toques_sr', 0)} "
            f"[{state.modo_mercado}]",
            "TRADE"
        )
        state.add_debug(
            f"Operación: {asset} {señal['direccion']} ${monto:.2f} "
            f"score={señal['score']} [{state.modo_mercado}]",
            tipo="TRADE"
        )
        return True

    except Exception as e:
        state.add_log(f"Excepción ejecutando {asset}: {e}", "ERROR")
        logger.exception(f"_ejecutar_operacion: {e}")
        return False
